create procedure procedure1()
BEGIN
  select * from demo;
END;

