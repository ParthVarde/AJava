create procedure procedure1(IN ident INTEGER(10))
BEGIN
  select * from demo where id = ident;
END;

